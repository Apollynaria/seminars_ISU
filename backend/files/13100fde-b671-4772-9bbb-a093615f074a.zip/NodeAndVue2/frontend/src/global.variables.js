export var globalVariables = {
    serverUrl: "http://localhost:3000/"
};
