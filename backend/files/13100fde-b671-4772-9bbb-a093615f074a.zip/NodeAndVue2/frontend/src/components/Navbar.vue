<template>
    <div id="app">
        <nav class="navbar navbar-light px-4" style="background-color: #B0DDFB;">
            <div class="container">
                <router-link to="/listCards" class="navbar-brand">Карточки</router-link>
            </div>
        </nav>
    </div>
</template>

<script>
    export default {
        name: "NavBar",
        data() {
            return {};
        }
    };
</script>