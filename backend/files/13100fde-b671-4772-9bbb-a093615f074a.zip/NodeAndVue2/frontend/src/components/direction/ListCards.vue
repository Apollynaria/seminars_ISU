<template>
    <div class="col-sm-8">
        <router-link class="btn btn-success mb-2" to="/addCard">Добавить карточку</router-link>
        <ul class="list-group">
            <li class="list-group-item" v-for="(card, index) in cards" :key="index">
                <div class="col-auto">
                    <div class="row">
                        <div class="col-auto">
                            <!--globalVariables подключается в main.js-->
                            <a :href="this.globalVariables.serverUrl + card.link"  target="_blank">
                                {{card.name}}
                            </a>
                        </div>
                        <div class="col-auto">
                            <button v-on:click="deleteCard(card.id)" class="btn btn-outline-danger btn-sm">Удалить</button>
                        </div>
                    </div>
                </div>
                <div class="col-auto">
                    <img :src="this.globalVariables.serverUrl + card.link" width="100">
                </div>
            </li>
        </ul>
    </div>
</template>

<script>
    import http from "../../http-common";
    export default {
        name: "ListCards",
        data() {
            return {
                cards: []
            };
        },
        methods: {
            getCards() {
                http
                    .get("/cards")
                    .then(response => {
                        this.cards = response.data;
                    })
                    .catch(e => {
                        console.log(e);
                    });
            },
            deleteCard(card_id) {
                http
                    .post("/deleteCard/" + card_id)
                    .then(() => {
                        this.getCards();
                    })
                    .catch(e => {
                        console.log(e);
                    });
            },
            // генерация ссылки из строки base64
            // сгенерированная ссылка действительна, только пока открыта страница
            getLink(base64, mime_type){
                var byteCharacters = atob(base64);
                var byteNumbers = new Array(byteCharacters.length);
                for (var i = 0; i < byteCharacters.length; i++) {
                    byteNumbers[i] = byteCharacters.charCodeAt(i);
                }
                var byteArray = new Uint8Array(byteNumbers);
                var file = new Blob([byteArray], { type: mime_type });
                var fileURL = URL.createObjectURL(file);
                return fileURL;
            }
        },
        mounted() {
            this.getCards();
        }
    }
</script>